import socket
import threading
import base64
from crypto_utils import (
    generate_rsa_keypair, decrypt_with_rsa,
    encrypt_with_aes, decrypt_with_aes
)
from datetime import datetime
aes_key = None
def receive_messages(sock, private_key):
    global aes_key
    while True:
        data, _ = sock.recvfrom(4096)  # Receive data from the socket
        if aes_key is None:
            encrypted_key = base64.b64decode(data)
            aes_key = decrypt_with_rsa(private_key, encrypted_key)
            print("Received and decrypted AES key.")
        else:
            try:
                decrypted = decrypt_with_aes(aes_key, data.decode())
                print("Message:", decrypted,"\t", datetime.now().strftime("%H:%M:%S"))
            except Exception as e:
                print("Decryption failed:", e)
                break  # Exit if decryption fails, possibly due to key mismatch or other issues
def main():
    global aes_key
    server_addr = ("localhost", 12345)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    # Generate RSA keys and send public key
    private_key, public_key = generate_rsa_keypair()
    sock.sendto(base64.b64encode(public_key), server_addr)

    # Start thread to receive messages
    threading.Thread(target=receive_messages, args=(sock, private_key), daemon=True).start()
    while True:
        msg = input("")
        if aes_key:
            encrypted = encrypt_with_aes(aes_key, msg)
            sock.sendto(encrypted.encode(), server_addr)
        else:
            print("Waiting for key exchange to complete...")
if __name__ == "__main__":
    main()
