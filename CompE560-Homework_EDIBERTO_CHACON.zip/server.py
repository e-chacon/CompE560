import socket
import threading
import base64
from crypto_utils import generate_aes_key, encrypt_with_rsa, decrypt_with_aes, encrypt_with_aes
from datetime import datetime

clients = {}
client_keys = {}

def handle_messages(sock):
    while True:
        data, addr = sock.recvfrom(4096)
        if addr in clients:
            aes_key = clients[addr]
            # Broadcast the encrypted message to other clients
            try:
                decrypted_message = decrypt_with_aes(aes_key, data.decode())
                print(f"Received from {addr}: {decrypted_message}", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            except Exception as e:
                print(f"Decryption failed for {addr}: {e}")
                continue

            for client_addr, key in clients.items():
                if client_addr != addr:
                    encrypted_message = encrypt_with_aes(key, decrypted_message)
                    sock.sendto(encrypted_message.encode(), client_addr)
        else:
            # First message is assumed to be client's RSA public key
            rsa_pub_key = base64.b64decode(data)
            aes_key = generate_aes_key()
            encrypted_key = encrypt_with_rsa(rsa_pub_key, aes_key)
            sock.sendto(base64.b64encode(encrypted_key), addr)
            clients[addr] = aes_key
            client_keys[addr] = rsa_pub_key
            print(f"Key exchanged with {addr}")

def main():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(("localhost", 12345))
    print("Server started on port 12345")
    handle_messages(sock)

if __name__ == "__main__":
    main()
